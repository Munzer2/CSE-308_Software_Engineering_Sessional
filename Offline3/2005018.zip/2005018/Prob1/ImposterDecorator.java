public class ImposterDecorator extends Passenger_decorator{

    public ImposterDecorator(Passenger someone) {
        super(someone);
    }
    @Override
    public void work(){
        passenger.work();
        kill();
    }
    private void kill(){
        System.out.println("Trying to kill a crewmate.\n" + "Successfully killed a crewmate.");
    }

    @Override
    public void repair(){
        passenger.repair();
        damage();
    }

    private void damage(){
        System.out.println("Damaging the spaceship.");
    }
}
