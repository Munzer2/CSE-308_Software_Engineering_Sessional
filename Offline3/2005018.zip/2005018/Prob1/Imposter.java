public class Imposter implements Passenger{
    @Override
    public void work() {
        System.out.println("Doing research");
    }
    @Override
    public void repair() {
        System.out.println("Repairing the spaceship.");
    }
}
