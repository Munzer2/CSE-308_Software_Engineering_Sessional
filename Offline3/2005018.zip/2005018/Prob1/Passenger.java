public interface Passenger {
    public void work();
    public void repair();
}
