public class Passenger_decorator {
    protected Passenger passenger;
    public Passenger_decorator(Passenger someone){
        this.passenger = someone;
    }
    public void work(){
        passenger.work();
    }
    public void repair(){
        passenger.repair();
    }
}
