import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        String choice;
        boolean flag = false;
        Passenger_decorator decorator = null;
        Scanner scanner = new Scanner(System.in);
        while(true){
            choice  = scanner.nextLine();
            if(choice.equalsIgnoreCase("Exit")){
                break;
            }
            else{
                if(!flag){
                    String arr[] = choice.split(" ");
                    if(arr[0].equalsIgnoreCase("login")){
                        flag = true;
                        String type = arr[1].substring(0,arr[1].length()-1);
                        if(type.equalsIgnoreCase("crew")){
                            System.out.println("Welcome Crewmate!");
                            decorator = new Passenger_decorator(new Crewmate());
                        }
                        else if(type.equalsIgnoreCase("imp")){
                            System.out.println("Welcome Crewmate!");
                            System.out.println("We won’t tell anyone; you are an imposter.");
                            decorator = new ImposterDecorator(new Imposter());
                        }
                        else{
                            System.out.println("Invalid Login.");
                            flag = false;
                        }
                    }
                    else{
                        System.out.println("Invalid command.");
                    }
                }
                else{
                    if(choice.equalsIgnoreCase("Logout")){
                        flag = false;
                        decorator = null;
                        System.out.println("Bye Bye Crewmate.");
                    }
                    else if(choice.equalsIgnoreCase("Work")){
                        decorator.work();
                    }
                    else if(choice.equalsIgnoreCase("Repair")){
                        decorator.repair();
                    }
                    else{
                        System.out.println("Invalid command.");
                    }
                }
            }
        }
    }
}