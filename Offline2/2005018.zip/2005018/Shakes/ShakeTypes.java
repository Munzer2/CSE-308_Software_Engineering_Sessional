package Shakes;

public enum ShakeTypes {
    Coffee,Strawberry,Chocolate,Vanilla,Zero
}
