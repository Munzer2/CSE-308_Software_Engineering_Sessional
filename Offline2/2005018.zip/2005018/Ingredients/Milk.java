package Ingredients;

public enum Milk {
    regular,Almond
}
