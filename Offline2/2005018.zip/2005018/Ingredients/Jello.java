package Ingredients;

public enum Jello {
    SugarFree,Sugar
}
