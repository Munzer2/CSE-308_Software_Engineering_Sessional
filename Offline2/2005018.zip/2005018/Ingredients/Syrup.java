package Ingredients;

public enum Syrup {
    Chocolate,Null,Strawberry
}
