package Ingredients;

public enum Flavors {
    Vanilla,Chocolate,Strawberry,Null,Coffee
}
