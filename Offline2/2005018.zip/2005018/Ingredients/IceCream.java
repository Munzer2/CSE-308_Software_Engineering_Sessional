package Ingredients;

public enum IceCream {
    Chocolate,Strawberry,Vanilla,Null
}
